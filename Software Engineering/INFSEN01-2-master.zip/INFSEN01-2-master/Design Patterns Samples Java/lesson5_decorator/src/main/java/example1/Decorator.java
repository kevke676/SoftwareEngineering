package example1;

import iterator1.safeCollections.Iterator;

interface Decorator<T> extends Iterator<T>{}
