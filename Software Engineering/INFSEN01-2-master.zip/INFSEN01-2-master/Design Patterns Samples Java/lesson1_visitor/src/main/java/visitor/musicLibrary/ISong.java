package visitor.musicLibrary;

public interface ISong {

    void visit(IMusicLibraryVisitor visitor);
}

