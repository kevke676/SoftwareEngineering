package visitor.number;

public interface INumber {

    void visit(INumberVisitor visitor);
}
