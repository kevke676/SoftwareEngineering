# INFSEN01-2
Design patterns in object oriented programming at Hogeschool Rotterdam

Note: The slides may contain the wrong course code.
