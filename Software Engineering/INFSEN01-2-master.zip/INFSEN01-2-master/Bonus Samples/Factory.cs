using System;

namespace Program
{
    /*
        Factory example
    */
    
    
    class Program
    {
        static void Main()
        {
	    
        }
    }
}
