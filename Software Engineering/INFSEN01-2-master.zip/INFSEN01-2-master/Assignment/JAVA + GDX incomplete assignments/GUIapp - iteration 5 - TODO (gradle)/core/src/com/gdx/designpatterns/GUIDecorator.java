package com.gdx.designpatterns;

public abstract class GUIDecorator // TODO: Missing code
}
