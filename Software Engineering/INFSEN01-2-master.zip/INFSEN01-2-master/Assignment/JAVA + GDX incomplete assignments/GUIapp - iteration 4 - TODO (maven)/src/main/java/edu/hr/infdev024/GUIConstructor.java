package edu.hr.infdev024;

public class GUIConstructor extends GUIMenuCreator {

    public GUIManager instantiate(String option, Runnable exitAction) {
        GUIManager guiManager = new GUIManager();

        //TODO: ADD MISSING CODE HERE
        return guiManager;
    }
}
