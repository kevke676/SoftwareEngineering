package edu.hr.infdev024;

public abstract class GUIElementCreator {
    //TODO: ADD MISSING CODE HERE
}
