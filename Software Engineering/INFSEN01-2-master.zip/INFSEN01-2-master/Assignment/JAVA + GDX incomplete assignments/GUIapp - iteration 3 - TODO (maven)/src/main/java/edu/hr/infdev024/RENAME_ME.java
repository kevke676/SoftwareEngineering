package edu.hr.infdev024;

//TODO: ADD MISSING CODE HERE
{
    void drawRectangle(Point top_left, Float width, Float height, CustomColor color);

    void drawString(String text, Point top_left, Integer size, CustomColor color);
}
