package edu.hr.infdev024;

// This interface should be implemented by all clickable GUI elements
interface IInputManager {
    //TODO: ADD MISSING CODE HERE
}
