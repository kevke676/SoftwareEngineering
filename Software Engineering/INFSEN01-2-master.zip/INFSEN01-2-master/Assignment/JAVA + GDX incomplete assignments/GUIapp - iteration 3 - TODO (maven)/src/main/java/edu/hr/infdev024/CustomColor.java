package edu.hr.infdev024;

// A framework-agnostic (independent) enumeration of colors
enum CustomColor {
    WHITE,
    BLACK,
    BLUE
}
