package com.gdx.designpatterns;

// Describes a common interface for iterating over collections
interface //TODO: MISSING CODE {
    IOption<T> getNext();
    IOption<T> getCurrent();
    void reset();
}
