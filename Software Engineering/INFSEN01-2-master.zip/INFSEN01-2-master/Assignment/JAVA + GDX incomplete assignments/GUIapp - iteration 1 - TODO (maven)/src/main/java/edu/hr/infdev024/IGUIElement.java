package edu.hr.infdev024;

// The base class of each GUI element
public interface IGUIElement extends IDrawable, IUpdatable {
}
