package com.gdx.designpatterns;

// Any updatable GUI element should implement this interface
interface IUpdatable {
       //TODO: ADD MISSING CODE HERE
}
