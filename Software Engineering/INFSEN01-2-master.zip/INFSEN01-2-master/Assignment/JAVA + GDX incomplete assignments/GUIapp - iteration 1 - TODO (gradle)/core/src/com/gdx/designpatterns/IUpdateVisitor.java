package com.gdx.designpatterns;

/*
  This interface may be used for describing the specifics
  of how each GUI element should be updated
*/
interface IUpdateVisitor {
       //TODO: ADD MISSING CODE HERE
}
