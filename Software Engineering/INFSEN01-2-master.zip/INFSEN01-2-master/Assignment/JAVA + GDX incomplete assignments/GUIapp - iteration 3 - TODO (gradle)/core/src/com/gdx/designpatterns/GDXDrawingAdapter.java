package com.gdx.designpatterns;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.Color;

// Describes the concrete libgdx drawing functionality
public class GDXDrawingAdapter implements IDrawingManager {
    private SpriteBatch batch;
    private Texture textureWhite;
    private BitmapFont font;
    
       //TODO: ADD MISSING CODE HERE

    // Converts a framework-agnostic color into a libgdx color
    private Color convertColor(CustomColor color) {
       //TODO: ADD MISSING CODE HERE
    }

        //TODO: ADD MISSING CODE HERE
    {
       //TODO: ADD MISSING CODE HERE
    }

    public void drawString(String text, Point top_left, Integer size, CustomColor color) {
       //TODO: ADD MISSING CODE HERE
    }
}
