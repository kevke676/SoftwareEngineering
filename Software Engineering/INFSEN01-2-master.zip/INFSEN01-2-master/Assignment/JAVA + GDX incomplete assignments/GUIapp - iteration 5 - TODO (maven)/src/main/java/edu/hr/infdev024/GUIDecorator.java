package edu.hr.infdev024;

public abstract class GUIDecorator // TODO: Missing code

}
