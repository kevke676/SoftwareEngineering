package edu.hr.infdev024;

import java.util.ArrayList;

// Describes a concrete iterator for array lists
public class ListIterator<T> implements IIterator<T> {
    //TODO: ADD MISSING CODE HERE
}
