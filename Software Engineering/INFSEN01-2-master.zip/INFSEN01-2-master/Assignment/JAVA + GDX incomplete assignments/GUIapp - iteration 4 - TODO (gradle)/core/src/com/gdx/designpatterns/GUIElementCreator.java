package com.gdx.designpatterns;

public abstract class GUIElementCreator {
       //TODO: ADD MISSING CODE HERE
}
