package com.gdx.designpatterns;

// Describes a concrete GUIElementCreator that makes buttons
public class ButtonConstructor extends GUIElementCreator {
    @Override
    public IGUIElement instantiate(String text, Point top_left, Integer size, CustomColor color) {
       //TODO: ADD MISSING CODE HERE
    }
    
    @Override
    public IGUIElement instantiate(String text, Point top_left, Integer size, CustomColor color, Float width, Float height, Runnable action) {
       //TODO: ADD MISSING CODE HERE
    }
}
