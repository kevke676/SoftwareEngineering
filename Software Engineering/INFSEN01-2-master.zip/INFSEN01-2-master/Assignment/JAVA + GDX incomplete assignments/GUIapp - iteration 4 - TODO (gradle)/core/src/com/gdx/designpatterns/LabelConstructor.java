package com.gdx.designpatterns;

// Describes a concrete GUIElementCreator that makes labels
public class LabelConstructor        //TODO: ADD MISSING CODE HERE
 {
       //TODO: ADD MISSING CODE HERE
}
