package com.gdx.designpatterns;

// Describes a class with a factory method for creating menu screens
public abstract class GUIMenuCreator {
//TODO: ADD MISSING CODE HERE
}
